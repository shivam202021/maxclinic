import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Clinic } from './clinic.model';
import { ClinicalService } from './clinical.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'maxclinic';
  ListResult:any=[];
  clinicObject:Clinic={
    clinicId: 0,
    userName: '',
    name: '',
    address: '',
    phoneNumber: '',
    zipcode: 0,
    city: '',
    state: '',
    email: '',
    contactPersonName: ''
  }
  ClinicForm!:FormGroup ;

  constructor(private clinicservice:ClinicalService,private fb:FormBuilder){
 this.ClinicForm=this.fb.group({

  clinicId: [""],
  userName: [""],
  name: [""],
  address:[""],
  phoneNumber: [""],
  zipcode: [""],
  city:[""],
  state:[""],
  email: [""],
  contactPersonName:[""],


 })
  }
  ngOnInit(): void {
    this.getData();

  }
  getZip(){
    this.clinicservice.getCityStateByZipCode(this.ClinicForm.value.zipcode).subscribe((res:any)=>{
      console.log(res)
      // this.ClinicForm.value.city=res.ResponseData.city;
      // this.ClinicForm.value.state=res.ResponseData.state;
      this.ClinicForm.controls['city'].setValue(res.ResponseData.City)
      this.ClinicForm.controls['state'].setValue(res.ResponseData.State)
    })
  }
  getData(){
    this.clinicservice.getMaxClinic().subscribe((res:any)=>{
      console.log(res)
      this.ListResult=res.ResponseData.ListResult

      console.log(this.ListResult)
     })
  }
  addData(){
    this.clinicObject.clinicId=this.ClinicForm.value.clinicId
    this.clinicObject.userName=this.ClinicForm.value.userName
    this.clinicObject.name=this.ClinicForm.value.name
    this.clinicObject.address=this.ClinicForm.value.address
    this.clinicObject.phoneNumber=this.ClinicForm.value.phoneNumber
    this.clinicObject.zipcode=this.ClinicForm.value.zipcode
    this.clinicObject.city=this.ClinicForm.value.city
    this.clinicObject.state=this.ClinicForm.value.state
    this.clinicObject.contactPersonName=this.ClinicForm.value.contactPersonName
    this.clinicObject.email=this.ClinicForm.value.email
    this.clinicservice.postMaxClinic(this.clinicObject).subscribe((res)=>{
      console.log(res)
      this.getData();
    })

  }

  saveIt(){
   console.log(this.ClinicForm.value)
  }
  EditData(data:any){
    this.ClinicForm.controls['clinicId'].setValue(data.ClinicId)
    this.ClinicForm.controls['userName'].setValue(data.UserName)
    this.ClinicForm.controls['name'].setValue(data.Name)
    this.ClinicForm.controls['address'].setValue(data.Address)
    this.ClinicForm.controls['phoneNumber'].setValue(data.PhoneNumber)
    this.ClinicForm.controls['zipcode'].setValue(data.Zipcode)
    this.ClinicForm.controls['city'].setValue(data.City)
    this.ClinicForm.controls['state'].setValue(data.State)
    this.ClinicForm.controls['contactPersonName'].setValue(data.ContactPersonName)
    this.ClinicForm.controls['email'].setValue(data.Email)

  }
  UpdateData(){
    this.clinicObject.clinicId=this.ClinicForm.value.clinicId
    this.clinicObject.userName=this.ClinicForm.value.userName
    this.clinicObject.name=this.ClinicForm.value.name
    this.clinicObject.address=this.ClinicForm.value.address
    this.clinicObject.phoneNumber=this.ClinicForm.value.phoneNumber
    this.clinicObject.zipcode=this.ClinicForm.value.zipcode
    this.clinicObject.city=this.ClinicForm.value.city
    this.clinicObject.state=this.ClinicForm.value.state
    this.clinicObject.contactPersonName=this.ClinicForm.value.contactPersonName
    this.clinicObject.email=this.ClinicForm.value.email
    this.clinicservice.updateMaxClinic(this.clinicObject).subscribe((res)=>{
      alert("data got updated")
      this.getData()
    })
  }
}
