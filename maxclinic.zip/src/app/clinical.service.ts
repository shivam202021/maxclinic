import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ClinicalService {
   baseurl:string ="https://apimaxcare.newtechtest.in/api/Clinic/GetClinicList?Page=1&PageSize=1000"
   postUrl:string ="https://apimaxcare.newtechtest.in/api/Clinic/InsertClinic"
   updateUrl: string ="https://apimaxcare.newtechtest.in/api/Clinic/UpdateClinic"
   zipUrl:string="https://apimaxcare.newtechtest.in/api/Common/GetCityAndStateByZipCode/"
  constructor(private http:HttpClient) { }
  getCityStateByZipCode(zipcode:number){
    return this.http.get(this.zipUrl+zipcode).pipe(map((res)=>{
      return res;
    }))
  }
  getMaxClinic(){
    return this.http.get(this.baseurl).pipe(map((res)=>{
      return res;
    }))
  }
  postMaxClinic(data:any){
    return this.http.post(this.postUrl,data).pipe(map((res)=>{
      return res;
    }))
  }
  updateMaxClinic(data:any){
    return this.http.post(this.updateUrl,data).pipe(map((res)=>{
      return res;
    }))
  }
  deleteClinic(id:number){
    return this.http.delete(this.baseurl+id).pipe(map((res)=>{
      return res;
    }))
  }
}
