export interface Clinic{
  clinicId: number,
  userName: string,
  name: string,
  address: string,
  phoneNumber: string,
  zipcode: 0,
  city: string,
  state: string,
  email: string,
  contactPersonName: string,


}

